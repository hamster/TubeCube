

#include <atmel_start.h>
#include <util/delay.h>
#include "characters.h"

//void SPISend(unsigned char data){
	//SPDR = data;
	//while(!(SPSR & (1 << SPIF)));
//}
//
void SetChar(unsigned long character){
	
	//PORTB |= (1 << 6);
	Strobe_set_level(true);
	//SPISend((character >> 16) & 0xFF);
	
	char data[3];
	data[2] = 0xff;
	data[1] = (character >> 8) & 0xFF;
	data[0] = character & 0xFF;
	SPI_0_write_block(data, 3);
	
	//SPISend(0x00);
	//SPISend((character >> 8) & 0xFF);
	//SPISend(character & 0xFF);
	//PORTB &= ~(1 << 6);
	Strobe_set_level(false);
	
}


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	//// Fire up the HVPS
	PWM_0_enable();
	PWM_0_load_counter(0);
	PWM_0_load_top(600);
	PWM_0_enable_output_ch2();
	
	PWM_0_load_duty_cycle_ch2(10*3*2);
	
	unsigned long counter = 0;
	
	while (1) {
		
		unsigned long count = 0;
		
		for(int i = 0; i < 16; i++){
			
			Strobe_set_level(true);
			
			_delay_ms(1);
			
			unsigned char data[3];
			data[2] = 0x55; //0x00; //(count >> 16) & 0xFF;
			data[1] = 0x55; //(count >> 8) & 0xFF;
			data[0] = 0x55; //(count & 0xFF);
			
			SPI_0_write_block(data, 3);
			
			_delay_ms(1);
			
			Strobe_set_level(false);
			
			count = 1 << i;
			
			_delay_ms(50);
		}
		

		
////		SetChar(SixteenSegmentASCII[counter++]);
		//if(counter++ > 0xFFFF){
			//counter = 0;
		//}
		//_delay_ms(50);
		
	}
	
	
}
