#include <atmel_start.h>
#include "characters.h"

//void SPISend(unsigned char data){
	//SPDR = data;
	//while(!(SPSR & (1 << SPIF)));
//}
//
//void SetChar(unsigned long character){
	//
	//PORTB |= (1 << 6);
	////SPISend((character >> 16) & 0xFF);
	//SPISend(0x00);
	//SPISend((character >> 8) & 0xFF);
	//SPISend(character & 0xFF);
	//PORTB &= ~(1 << 6);
	//
//}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	// Fire up the HVPS
	PWM_0_enable();
	
	PWM_0_load_counter(0xFF);
	PWM_0_load_top(128);
	
	while (1) {
	}
	
	
}
